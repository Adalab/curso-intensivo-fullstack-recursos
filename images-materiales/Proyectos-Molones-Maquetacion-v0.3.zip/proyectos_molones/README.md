# Proyectos molones

Tenemos un primer intento de maquetación de otra empresa que finalmente no pudo con la complejidad del proyecto.

Dado el diseño de la página, empezaron a maquetar la página del formulario para crear una tarjeta. El diseño no está completo (faltan por ajustar detalles y el responsive).

Espero que os ayude a avanzar en el proyecto.

Al turrón!